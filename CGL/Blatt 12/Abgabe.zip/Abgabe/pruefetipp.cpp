#include <iostream>

// Definition der Pr�ffunktion
bool pruefeTipp(int tipp, int loesung) {
    if (tipp == loesung) {
        std::cout << "Treffer! Gut gemacht." << std::endl;
        return true; // R�ckgabe f�r True
    }
    else if (tipp > loesung) { // Tipp gr��er als die L�sung
        std::cout << "Zu hoch!" << std::endl;
    }
    else {
        std::cout << "Zu niedrig!" << std::endl;
    }
    return false; // R�ckgabe f�r False
}

int main() {
    int guess;
    bool gefunden = false;

    std::cout << "Willkommen zum Zahlen-Raten!" << std::endl;

    while (!gefunden) {
        std::cout << "Dein Tipp: ";
        std::cin >> guess;

        gefunden = pruefeTipp(guess, secret);
    }

    return 0;
}